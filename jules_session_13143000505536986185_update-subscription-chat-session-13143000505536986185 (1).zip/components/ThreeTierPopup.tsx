import React, { useState, useEffect } from 'react';
import { X, Crown, Zap, Star, Check } from 'lucide-react';

interface Props {
  onClose: () => void;
  onUpgrade: () => void;
  isOpen: boolean;
}

export const ThreeTierPopup: React.FC<Props> = ({ onClose, onUpgrade, isOpen }) => {
  const [slide, setSlide] = useState(0); // 0: Free, 1: Basic, 2: Ultra
  const [timer, setTimer] = useState(9); // Total 9s
  const [skipTimer, setSkipTimer] = useState(5); // 5s to skip

  useEffect(() => {
    if (!isOpen) return;

    // Slide cycler (every 3s)
    const slideInterval = setInterval(() => {
      setSlide(prev => (prev + 1) % 3);
    }, 3000);

    // Global countdown
    const globalTimer = setInterval(() => {
        setTimer(prev => {
            if (prev <= 1) {
                onClose(); // Auto close
                return 0;
            }
            return prev - 1;
        });
        setSkipTimer(prev => prev > 0 ? prev - 1 : 0);
    }, 1000);

    return () => {
      clearInterval(slideInterval);
      clearInterval(globalTimer);
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center bg-black/90 backdrop-blur-md animate-in fade-in">
        {/* SKIP BUTTON */}
        <div className="absolute top-8 right-8 z-50">
            {skipTimer > 0 ? (
                <div className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center text-white font-bold border-2 border-white/20">
                    {skipTimer}
                </div>
            ) : (
                <button 
                    onClick={onClose}
                    className="bg-white/20 hover:bg-white/30 text-white px-4 py-2 rounded-full text-xs font-bold transition-all border border-white/20"
                >
                    Skip & Close
                </button>
            )}
        </div>

        {/* CONTENT */}
        <div className="w-full max-w-sm mx-4 relative perspective-1000">
            {/* CARDS */}
            <div className="relative h-[500px] w-full">
                {/* FREE CARD */}
                <div className={`absolute inset-0 bg-white rounded-3xl p-6 transition-all duration-700 ease-in-out transform ${slide === 0 ? 'opacity-100 translate-x-0 scale-100 z-30' : 'opacity-0 -translate-x-full scale-90 z-10'}`}>
                    <div className="h-full flex flex-col items-center text-center">
                        <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mb-6">
                            <Star size={40} className="text-slate-500" />
                        </div>
                        <h2 className="text-3xl font-black text-slate-800 mb-2">FREE PLAN</h2>
                        <p className="text-slate-500 text-sm mb-8">Good for getting started</p>
                        
                        <ul className="space-y-3 text-left w-full pl-4 mb-auto">
                            <li className="flex items-center gap-3 text-slate-700 text-sm font-bold"><Check size={16} className="text-green-500" /> Global Leaderboard</li>
                            <li className="flex items-center gap-3 text-slate-700 text-sm font-bold"><Check size={16} className="text-green-500" /> Basic Notes</li>
                            <li className="flex items-center gap-3 text-slate-700 text-sm font-bold"><Check size={16} className="text-green-500" /> Daily Streak</li>
                            <li className="flex items-center gap-3 text-slate-700 text-sm font-bold"><Check size={16} className="text-green-500" /> 3 Coins/Day Bonus</li>
                        </ul>
                    </div>
                </div>

                {/* BASIC CARD */}
                <div className={`absolute inset-0 bg-gradient-to-b from-blue-50 to-white rounded-3xl p-6 transition-all duration-700 ease-in-out transform ${slide === 1 ? 'opacity-100 translate-x-0 scale-100 z-30' : slide > 1 ? 'opacity-0 -translate-x-full scale-90 z-10' : 'opacity-0 translate-x-full scale-90 z-10'}`}>
                    <div className="h-full flex flex-col items-center text-center border-2 border-blue-500 rounded-3xl relative overflow-hidden">
                        <div className="absolute top-0 inset-x-0 h-2 bg-blue-500"></div>
                        <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mb-6 mt-6">
                            <Zap size={40} className="text-blue-600" />
                        </div>
                        <h2 className="text-3xl font-black text-blue-900 mb-2">BASIC PLAN</h2>
                        <p className="text-blue-600 text-sm mb-8 font-bold">Standard Learning</p>
                        
                        <ul className="space-y-3 text-left w-full pl-8 mb-auto">
                            <li className="flex items-center gap-3 text-slate-800 text-sm font-bold"><Check size={16} className="text-blue-500" /> 10 Coins/Day Bonus</li>
                            <li className="flex items-center gap-3 text-slate-800 text-sm font-bold"><Check size={16} className="text-blue-500" /> Full MCQ Access</li>
                            <li className="flex items-center gap-3 text-slate-800 text-sm font-bold"><Check size={16} className="text-blue-500" /> Premium Notes</li>
                            <li className="flex items-center gap-3 text-slate-800 text-sm font-bold"><Check size={16} className="text-blue-500" /> Team Support</li>
                        </ul>
                    </div>
                </div>

                {/* ULTRA CARD */}
                <div className={`absolute inset-0 bg-gradient-to-b from-purple-900 to-indigo-900 rounded-3xl p-6 transition-all duration-700 ease-in-out transform ${slide === 2 ? 'opacity-100 translate-x-0 scale-100 z-30' : 'opacity-0 translate-x-full scale-90 z-10'}`}>
                    <div className="h-full flex flex-col items-center text-center text-white border-2 border-yellow-400 rounded-3xl relative overflow-hidden shadow-2xl shadow-purple-500/50">
                        <div className="absolute top-4 right-4 animate-bounce"><Crown size={24} className="text-yellow-400" /></div>
                        <div className="w-20 h-20 bg-white/10 rounded-full flex items-center justify-center mb-6 mt-6 backdrop-blur-sm border border-white/20">
                            <Crown size={40} className="text-yellow-400" />
                        </div>
                        <h2 className="text-3xl font-black text-white mb-2">ULTRA PLAN</h2>
                        <p className="text-purple-200 text-sm mb-8 font-bold">For Toppers</p>
                        
                        <ul className="space-y-3 text-left w-full pl-8 mb-auto">
                            <li className="flex items-center gap-3 text-white text-sm font-bold"><Check size={16} className="text-yellow-400" /> 20 Coins/Day Bonus</li>
                            <li className="flex items-center gap-3 text-white text-sm font-bold"><Check size={16} className="text-yellow-400" /> Deep 3D Videos</li>
                            <li className="flex items-center gap-3 text-white text-sm font-bold"><Check size={16} className="text-yellow-400" /> Competitive Mode</li>
                            <li className="flex items-center gap-3 text-white text-sm font-bold"><Check size={16} className="text-yellow-400" /> Direct Teacher Access</li>
                        </ul>

                        <button 
                            onClick={onUpgrade}
                            className="w-full bg-gradient-to-r from-yellow-400 to-orange-500 text-black font-black py-4 rounded-xl shadow-lg mt-4 animate-pulse"
                        >
                            GET ULTRA NOW
                        </button>
                    </div>
                </div>
            </div>

            {/* INDICATORS */}
            <div className="flex justify-center gap-2 mt-6">
                {[0, 1, 2].map(i => (
                    <div key={i} className={`h-2 rounded-full transition-all duration-300 ${slide === i ? 'w-8 bg-white' : 'w-2 bg-white/30'}`} />
                ))}
            </div>
        </div>
    </div>
  );
};
